"""Build editable publication files from the self-contained article HTML."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import subprocess
import sys
import zipfile

from lxml import etree, html
from docx import Document
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

ROOT = Path(__file__).resolve().parent
ARTICLE = ROOT / 'Stakeholders_Letter_Eleven_Inputs.html'
NAME = 'Stakeholders_Letter_Eleven_Inputs'


def math_run(text):
    run = OxmlElement('m:r')
    value = OxmlElement('m:t')
    value.text = text
    run.append(value)
    return run


def math_text(parent, text):
    for part in re.split(r'(\d+/\d+)', text or ''):
        if re.fullmatch(r'\d+/\d+', part):
            num, den = part.split('/')
            frac = OxmlElement('m:f')
            for name, value in [('num', num), ('den', den)]:
                node = OxmlElement('m:' + name)
                node.append(math_run(value))
                frac.append(node)
            parent.append(frac)
        elif part:
            parent.append(math_run(part))


def equation(paragraph, node):
    equation_node = OxmlElement('m:oMath')
    math_text(equation_node, node.text)
    for child in node:
        if child.tag in ('sub', 'sup') and len(equation_node):
            previous = equation_node[-1]
            equation_node.remove(previous)
            notation = OxmlElement('m:sSub' if child.tag == 'sub' else 'm:sSup')
            base = OxmlElement('m:e')
            base.append(previous)
            notation.append(base)
            script = OxmlElement('m:sub' if child.tag == 'sub' else 'm:sup')
            script.append(math_run(''.join(child.itertext())))
            notation.append(script)
            equation_node.append(notation)
        else:
            math_text(equation_node, ''.join(child.itertext()))
        math_text(equation_node, child.tail)
    paragraph._p.append(equation_node)


def inline(paragraph, node, bold=False, italic=False):
    def put(value, **kwargs):
        if not value:
            return
        run = paragraph.add_run(value)
        run.bold, run.italic = kwargs.get('bold', bold), kwargs.get('italic', italic)
        run.font.color.rgb = RGBColor(0, 0, 0)
        return run
    put(node.text)
    for child in node:
        if child.tag == 'br':
            paragraph.add_run().add_break()
        elif child.tag in ('sub', 'sup'):
            run = put(''.join(child.itertext()))
            if run is not None:
                run.font.subscript = child.tag == 'sub'
                run.font.superscript = child.tag == 'sup'
        else:
            inline(paragraph, child, bold or child.tag in ('strong', 'b'), italic or child.tag in ('em', 'i'))
        put(child.tail)


def make_document():
    document = Document()
    sec = document.sections[0]
    sec.page_width, sec.page_height = Inches(8.5), Inches(11)
    sec.top_margin, sec.bottom_margin = Inches(.75), Inches(.7)
    sec.left_margin = sec.right_margin = Inches(.8)
    sec.header_distance, sec.footer_distance = Inches(.3), Inches(.3)
    for style in document.styles:
        if style.type == 1:
            style.font.color.rgb = RGBColor(0, 0, 0)
    normal = document.styles['Normal']
    normal.font.name, normal.font.size = 'Calibri', Pt(11)
    normal.paragraph_format.line_spacing = 1.12
    normal.paragraph_format.space_after = Pt(7)
    normal.paragraph_format.widow_control = True
    for name, size in [('Title', 25), ('Heading 1', 17), ('Heading 2', 13)]:
        style = document.styles[name]
        style.font.name, style.font.size = 'Calibri', Pt(size)
        style.font.bold = True
        style.paragraph_format.space_before = Pt(14 if name != 'Title' else 0)
        style.paragraph_format.space_after = Pt(7)
        style.paragraph_format.keep_with_next = True
    header = sec.header.paragraphs[0]
    header.add_run('THE STAKEHOLDERS LETTER').font.size = Pt(8)
    footer = sec.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    footer.add_run('20 October 2026  |  ').font.size = Pt(8)
    field = OxmlElement('w:fldSimple'); field.set(qn('w:instr'), 'PAGE')
    footer._p.append(field)
    document.core_properties.title = 'Why eleven inputs cannot guarantee an accurate sample'
    document.core_properties.author = 'Fred Esser'
    document.core_properties.subject = 'The Stakeholders Letter with mathematical proof and reproducible evidence'
    document.core_properties.comments = 'Prepared with AI-assisted research and drafting. External review and novelty unverified.'

    tree = html.parse(str(ARTICLE))
    main = tree.xpath('//main')[0]

    def visit(element):
        for node in element:
            if node.tag in ('section', 'div'):
                visit(node)
            elif node.tag == 'h1':
                inline(document.add_paragraph(style='Title'), node)
            elif node.tag in ('h2', 'h3'):
                paragraph = document.add_paragraph(style='Heading 1' if node.tag == 'h2' else 'Heading 2')
                if ''.join(node.itertext()) == 'Technical appendix':
                    paragraph.paragraph_format.page_break_before = True
                inline(paragraph, node)
            elif node.tag == 'p':
                paragraph = document.add_paragraph()
                klass = node.get('class', '')
                if klass == 'eq':
                    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    equation(paragraph, node)
                else:
                    inline(paragraph, node)
                if klass in ('brand', 'byline', 'status'):
                    for run in paragraph.runs:
                        run.font.size = Pt(9 if klass != 'status' else 10)
                    if klass in ('brand', 'byline'):
                        paragraph.paragraph_format.keep_with_next = True
            elif node.tag == 'pre':
                paragraph = document.add_paragraph()
                for index, line in enumerate(''.join(node.itertext()).splitlines()):
                    if index:
                        paragraph.add_run().add_break()
                    run = paragraph.add_run(line)
                    run.font.name, run.font.size = 'Consolas', Pt(8.5)
                paragraph.paragraph_format.keep_together = True
            elif node.tag == 'table':
                rows = node.xpath('.//tr')
                count = len(rows[0])
                table = document.add_table(rows=0, cols=count)
                table.autofit = False
                widths = [2.35, 4.55] if count == 2 else [.6, .9, 5.4]
                for column, width in zip(table.columns, widths):
                    column.width = Inches(width)
                borders = OxmlElement('w:tblBorders')
                for side in ('top','left','bottom','right','insideH','insideV'):
                    border = OxmlElement('w:' + side)
                    for key, val in [('val','single'),('sz','4'),('color','D9D9D9')]:
                        border.set(qn('w:' + key),val)
                    borders.append(border)
                table._tbl.tblPr.append(borders)
                for row_index, source_row in enumerate(rows):
                    row = table.add_row()
                    rowpr = row._tr.get_or_add_trPr()
                    rowpr.append(OxmlElement('w:cantSplit'))
                    if row_index == 0:
                        rowpr.append(OxmlElement('w:tblHeader'))
                    for col_index, source_cell in enumerate(source_row):
                        cell = row.cells[col_index]
                        cell.width = Inches(widths[col_index])
                        cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
                        tcpr = cell._tc.get_or_add_tcPr()
                        margins = OxmlElement('w:tcMar')
                        for side in ('top','bottom','left','right'):
                            margin = OxmlElement('w:' + side)
                            margin.set(qn('w:w'),'95'); margin.set(qn('w:type'),'dxa')
                            margins.append(margin)
                        tcpr.append(margins)
                        if row_index == 0 or row_index % 2 == 0:
                            shade = OxmlElement('w:shd')
                            shade.set(qn('w:fill'), 'E8EEF3' if row_index == 0 else 'F7F9FA')
                            tcpr.append(shade)
                        para = cell.paragraphs[0]
                        para.paragraph_format.space_after = Pt(0)
                        para.paragraph_format.line_spacing = 1.05
                        inline(para, source_cell, bold=row_index == 0)
                        for run in para.runs:
                            run.font.size = Pt(10)
                document.add_paragraph().paragraph_format.space_after = Pt(1)
    visit(main)
    # Remove built-in title-rule residue and inherited paragraph borders.
    for container in (document.styles.element, document._element):
        for border in container.xpath('.//w:pBdr'):
            border.getparent().remove(border)
    output = ROOT / (NAME + '.docx')
    document.save(output)
    text_blocks = []
    for node in main.iter():
        if node.tag in ('h1','h2','h3','p','pre'):
            text_blocks.append(''.join(node.itertext()))
        elif node.tag == 'tr':
            text_blocks.append(' | '.join(''.join(cell.itertext()) for cell in node))
    (ROOT / (NAME + '.txt')).write_text('\n\n'.join(text_blocks) + '\n', encoding='utf-8')
    # Ready for a blog editor that accepts an HTML fragment; no external assets.
    (ROOT / (NAME + '_Blog_Fragment.html')).write_text(
        '\n'.join(etree.tostring(n, encoding='unicode', method='html') for n in main), encoding='utf-8')
    return output


def evidence():
    source = ROOT.parent / 'determine_20261020/proof'
    target = ROOT / 'evidence'
    for name in ['eleven_point_obstruction.py','constructive_eleven_check.json']:
        shutil.copy2(source / name, target / name)
    fresh = subprocess.run([sys.executable, str(target/'publication_sanity_check.py')], check=True, capture_output=True, text=True)
    (target / 'publication_sanity_check.json').write_text(fresh.stdout)
    repeated = subprocess.run([sys.executable, str(target/'eleven_point_obstruction.py'), '--samples', '1000'], check=True, capture_output=True, text=True)
    assert json.loads(repeated.stdout) == json.loads((target/'constructive_eleven_check.json').read_text())
    print(fresh.stdout)
    print('Original seeded output reproduced exactly')


def archive():
    files = sorted(p for p in ROOT.rglob('*') if p.is_file() and p.suffix in ('.py','.json','.docx','.html','.txt') and '__pycache__' not in p.parts and p.name != 'SHA256SUMS.txt')
    manifest = ''.join(hashlib.sha256(p.read_bytes()).hexdigest() + '  ' + p.relative_to(ROOT).as_posix() + '\n' for p in files)
    (ROOT/'SHA256SUMS.txt').write_text(manifest)
    files.append(ROOT/'SHA256SUMS.txt')
    path = ROOT.parent/'output'/'Stakeholders_Letter_Eleven_Inputs_Publication_Pack.zip'
    path.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as out:
        for item in files:
            out.write(item, item.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(path) as inp:
        assert inp.testzip() is None
        for line in manifest.splitlines():
            digest, name = line.split('  ',1)
            assert hashlib.sha256(inp.read(name)).hexdigest() == digest
    print(json.dumps({'archive':str(path),'files':len(files),'bytes':path.stat().st_size,'verified':True}))


if __name__ == '__main__':
    if '--archive' in sys.argv:
        archive()
    else:
        print(make_document())
        if '--doc-only' not in sys.argv:
            evidence()
