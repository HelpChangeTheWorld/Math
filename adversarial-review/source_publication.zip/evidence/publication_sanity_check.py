"""Independent finite checks for The Stakeholders Letter, standard library only.

This is not an exhaustive check of all eleven-element supports and is not a
proof assistant. The accompanying analytic proof establishes universality.
"""
from collections import Counter
from fractions import Fraction
from itertools import combinations, product
import json


def run_checks():
    representatives = Counter()
    for columns in combinations(range(1, 16), 11):
        counts = Counter(columns)
        counts.update(a ^ b for a, b in combinations(columns, 2))
        for syndrome in range(1, 16):
            representatives[counts[syndrome]] += 1
            assert counts[syndrome] >= 4
    assert sum(representatives.values()) == 20475

    # Independent indexing: x[0] is displayed x1, the most significant bit.
    words = [tuple((number >> (5 - i)) & 1 for i in range(6))
             for number in range(64)]
    support = [15, 21, 23, 27, 29, 30, 31, 38, 43, 56, 63]
    accepted = []
    full = 0
    for number, x in enumerate(words):
        formula = (x[4] & x[5]) ^ x[3] ^ x[4] ^ x[5]
        q = 1 ^ x[5]
        q &= 1 ^ x[4]
        q ^= x[3] ^ 1
        for _ in (x[2], x[1], x[0]):
            q = q
        assert q == formula
        full += q
        if number in support and q:
            accepted.append(number)
    assert accepted == [27, 43] and full == 32

    formula_count = 0
    for i, j in combinations(range(6), 2):
        rest = [k for k in range(6) if k not in (i, j)]
        for a in product((0, 1), repeat=6):
            if not any(a[k] for k in rest):
                continue
            for b in (0, 1):
                ones = 0
                for x in words:
                    expected = (x[i] & x[j]) ^ b
                    for k in range(6):
                        expected ^= a[k] & x[k]
                    q = x[i] ^ a[j]
                    q &= x[j] ^ a[i]
                    for index, k in enumerate(rest):
                        q ^= a[k] & x[k]
                        if index == 0:
                            q ^= b ^ (a[i] & a[j])
                    assert q == expected
                    ones += q
                assert ones == 32
                formula_count += 1
    assert formula_count == 1800
    return {
        "syndrome_cases": sum(representatives.values()),
        "representative_count_distribution": dict(sorted(representatives.items())),
        "example_coordinate_convention": "x1 is most significant bit",
        "example_sample_accepted_words": accepted,
        "example_full_cube_accepted": full,
        "example_exact_error": str(Fraction(full, 64) - Fraction(len(accepted), 11)),
        "quadratic_formulas_checked": formula_count,
        "inputs_per_formula": 64,
        "all_checks_passed": True,
    }


if __name__ == "__main__":
    print(json.dumps(run_checks(), indent=2))
