"""Exact constructive obstruction for 11 distinct points of F2^6.
Internal coordinate indices are LSB0. Displayed orders use x1=MSB.
Uses only Python standard library; no search over branching programs.
"""
import argparse,itertools,json,random
from fractions import Fraction
from pathlib import Path

def parity(x):return x.bit_count()&1

def execute_and_verify(support, order, transitions, formula):
    mask=0
    for x in range(64):
        state=0
        for k,code in zip(order,transitions):state=(code>>(2*state+((x>>k)&1)))&1
        expected=parity(x&formula['a_mask_lsb0'])^formula['b']
        if formula['kind']=='quadratic':
            i,j=formula['product_bits_lsb0'];expected^=((x>>i)&1)&((x>>j)&1)
        assert state==expected
        mask|=state<<x
    accepted=sum((mask>>x)&1 for x in support);full=mask.bit_count()
    error=abs(Fraction(accepted,11)-Fraction(full,64))
    assert full==32 and error>=Fraction(7,22)>Fraction(1,4)
    return {'support':support,'formula':formula,'order_x1_msb':[6-k for k in order],
            'transition_codes':transitions,'start_state':0,'accept_state':1,
            'function_mask':mask,'sample_accepted':accepted,'full_accepted':full,
            'exact_error':str(error)}

def affine_program(a,b):
    order=list(range(6))
    transitions=[sum((s^(((a>>k)&1)&z)^(b if k==0 else 0))<<(2*s+z)
                     for s in range(2) for z in range(2)) for k in order]
    return order,transitions

def quadratic_program(i,j,a,b):
    alpha=(a>>i)&1;beta=(a>>j)&1
    rest=[k for k in range(6) if k not in (i,j)]
    order=[i,j,*rest]
    transitions=[sum((z^beta)<<(2*s+z) for s in range(2) for z in range(2)),
                 sum((s&(z^alpha))<<(2*s+z) for s in range(2) for z in range(2))]
    constant=b^(alpha&beta)
    for k in rest:
        transitions.append(sum((s^(((a>>k)&1)&z)^(constant if k==rest[0] else 0))<<(2*s+z)
                               for s in range(2) for z in range(2)))
    return order,transitions

def witness(support):
    assert len(support)==len(set(support))==11
    assert all(type(x)is int and 0<=x<64 for x in support)
    affine={}
    for a in range(64):
        for b in range(2):
            ev=sum((parity(x&a)^b)<<t for t,x in enumerate(support))
            affine[ev]=(a,b)
            if a and (ev.bit_count()<=2 or ev.bit_count()>=9):
                order,transitions=affine_program(a,b)
                return execute_and_verify(support,order,transitions,{'kind':'affine','a_mask_lsb0':a,'b':b})
    assert len(affine)==128
    assert min(ev.bit_count() for ev in affine if ev)>=3
    columns=[sum(((x>>j)&1)<<t for t,x in enumerate(support)) for j in range(6)]
    for i,j in itertools.combinations(range(6),2):
        h=columns[i]&columns[j]
        if h in affine:continue
        # By the proof, this coset has >=4 weight-at-most-two vectors;
        # at most3 arise from affine corrections involving only i,j.
        low=[(h^ev,a,b) for ev,(a,b) in affine.items() if (h^ev).bit_count()<=2]
        assert len(low)>=4
        local=[(v,a,b) for v,a,b in low if not(a&~((1<<i)|(1<<j)))]
        assert len(local)<=3
        for v,a,b in low:
            if not(a&~((1<<i)|(1<<j))):continue
            order,transitions=quadratic_program(i,j,a,b)
            result=execute_and_verify(support,order,transitions,{'kind':'quadratic',
                    'product_bits_lsb0':[i,j],'a_mask_lsb0':a,'b':b})
            result['coset_low_weight_count']=len(low)
            result['local_low_weight_count']=len(local)
            return result
    raise AssertionError('A proper separating affine evaluation code cannot be a subalgebra.')

def syndrome_count_check():
    checked=0;minimum=100
    for omitted in itertools.combinations(range(1,16),4):
        H=[v for v in range(1,16) if v not in omitted]
        counts=[0]*16
        for v in H:counts[v]+=1
        for a,b in itertools.combinations(H,2):counts[a^b]+=1
        assert min(counts[1:])>=4
        minimum=min(minimum,min(counts[1:]));checked+=1
    return {'eleven_column_subsets_checked':checked,'nonzero_syndromes_per_subset':15,
            'minimum_weight_at_most_two_representatives':minimum}

def independent_basis(rng):
    basis=[];span={0}
    while len(basis)<6:
        v=rng.randrange(1,64)
        if v not in span:basis.append(v);span|={v^w for w in tuple(span)}
    return basis

def transform(x,basis,translation):
    for j in range(6):
        if(x>>j)&1:translation^=basis[j]
    return translation

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--samples',type=int,default=1000)
    parser.add_argument('--support',type=int,nargs=11)
    args=parser.parse_args()
    if args.support:
        print(json.dumps(witness(args.support),indent=2));raise SystemExit
    canonical=[56,38,30,43,21,29,27,23,15,63,31]
    rng=random.Random(20261020);counts={}
    for _ in range(args.samples):
        result=witness(rng.sample(range(64),11));kind=result['formula']['kind'];counts[kind]=counts.get(kind,0)+1
    embeddings={}
    for _ in range(args.samples):
        basis=independent_basis(rng);shift=rng.randrange(64)
        result=witness([transform(x,basis,shift)for x in canonical]);kind=result['formula']['kind']
        assert kind=='quadratic';embeddings[result['exact_error']]=embeddings.get(result['exact_error'],0)+1
    output={'canonical_witness':witness(canonical),'syndrome_lemma_check':syndrome_count_check(),
            'random_seed':20261020,'random_supports_checked':args.samples,'random_support_witness_counts':counts,
            'random_affine_embeddings_checked':args.samples,'affine_embedding_error_histogram':embeddings}
    print(json.dumps(output,indent=2))
