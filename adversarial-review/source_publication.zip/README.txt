THE STAKEHOLDERS LETTER
Eleven input sampling result
Publication package dated 20 October 2026

START HERE
Stakeholders_Letter_Eleven_Inputs.docx is the editable article and full technical
appendix. Stakeholders_Letter_Eleven_Inputs.html is the same content as a
self-contained browser document. The TXT file provides plain copyable text.

FOR YOUR BLOG
The public article is written in Fred Esser's voice for The Stakeholders Letter.
Open the HTML file and copy the rendered content into your blog's visual editor,
or use Stakeholders_Letter_Eleven_Inputs_Blog_Fragment.html in an HTML editor.
The fragment contains article content only. The complete HTML has the styling.
No scripts, external fonts, trackers, or image dependencies are required.

The article refers to an accompanying publication ZIP. If you publish the article,
attach this ZIP or upload it somewhere readers can access and link to that file.
No public download URL has been invented, and nothing has been published for you.
The main letter can be a post; the technical appendix can remain below it or be
a linked companion page. Preserve the model assumptions, AI disclosure, review
status, and references when adapting the text.

WHAT THE CENTRAL RESULT CLAIMS
For every eleven-element subset of the six-bit cube with equal sample weights,
there is a deterministic width-two read-once program in a suitable fixed order
with acceptance-probability discrepancy at least 7/22, exceeding 1/4.
It does not prove twelve-point sufficiency or establish originality.

REPRODUCE FROM THIS DIRECTORY
Python 3.10 or newer, standard library only:

python3 evidence/eleven_point_obstruction.py --samples 1000
python3 evidence/publication_sanity_check.py
python3 evidence/eleven_point_obstruction.py --support 15 21 23 27 29 30 31 38 43 56 63

Saved outputs:
evidence/constructive_eleven_check.json
evidence/publication_sanity_check.json

The original constructive output was rerun while preparing this package and
matched its archived JSON exactly. The publication sanity checker is separately
written, uses the opposite internal coordinate indexing from the original code,
and checks every syndrome case, the worked example, and all 1,800 quadratic
implementations including constants. The analytic proof covers all supports;
the randomized checks are supplementary.

REVIEW PROVENANCE
The article accurately summarizes four fresh AI reviewers and distinguishes their
reported computations from archived, reproducible checks. No external human
peer review, proof-assistant certification, or verified novelty is claimed.
The example explicitly defines x1 as the most significant bit, correcting an
ambiguity in the earlier prose. Earlier private project files remain unchanged.

PACKAGE CONTENTS
- DOCX, full HTML, blog HTML fragment, and plain-text article
- Two Python verification scripts and their saved outputs
- This README and SHA256SUMS.txt for packaged file integrity
- build_publication.py, the document construction source

REBUILD NOTES
The verification scripts above are portable and self-contained. The document
builder requires python-docx and lxml. Its evidence-copy/rerun step expects the
original project directory determine_20261020/proof alongside this folder; that
project-only convenience step is not needed to run any published checks.

The citations link to primary research for context. Those authors have not been
contacted or represented as endorsing this work. The exact finite theorem should
be evaluated independently of the related literature's authority.
